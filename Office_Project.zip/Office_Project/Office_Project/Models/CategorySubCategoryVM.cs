﻿namespace Office_Project.Models
{
    public class CategorySubCategoryVM
    {
        public int CategoryId { get; set; }
        public int SubCategoryId { get; set; }

        public List<Category> Categories { get; set; }
        public List<SubCategory> SubCategories { get; set; }
    }
}

﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Office_Project.Data;
using Office_Project.Models;
using Office_Project.Static;

namespace Office_Project.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly AppDBContext db;
        public AccountController(UserManager<ApplicationUser> _userManager, SignInManager<ApplicationUser> _signInManager, AppDBContext db)
        {
            this._userManager = _userManager;
            this._signInManager = _signInManager;
            this.db = db;
        }
        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Login(LoginVM obj)
        {
            if (ModelState.IsValid == true)
            {
                var User = await _userManager.FindByEmailAsync(obj.Email);
                if (User != null)
                {
                    var Pass = await _userManager.CheckPasswordAsync(User, obj.Password);
                    if (Pass)
                    {
                        var data = await _signInManager.PasswordSignInAsync(User, obj.Password, false, false);
                        if (data.Succeeded)
                        {
                            return RedirectToAction("Index", "Home");
                        }
                    }
                    TempData["Error"] = "Wrong Credentials.....Please, try again";
                    return View(obj);

                }
                TempData["Error"] = "Wrong Credentials.....Please, try again";
                return View(obj);
            }
            return View(obj);
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Register(RegisterVM obj)
        {
            if (ModelState.IsValid == true)
            {
                var User = await _userManager.FindByEmailAsync(obj.Email);
                if (User != null)
                {
                    TempData["Error"] = "This Email Address is already in use";
                    return View(obj);
                }
                var newuser = new ApplicationUser()
                {
                    FullName = obj.FullName,
                    Email = obj.Email,
                    UserName = obj.Email,
                    EmailConfirmed = true
                };
                var newUserResponse = await _userManager.CreateAsync(newuser, obj.Password);
                if (newUserResponse.Succeeded)
                {
                    await _userManager.AddToRoleAsync(newuser, UsersRole.User);
                }
                return RedirectToAction("Index", "Home");
            }
            return View(obj);
        }
        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Movie");
        }
    }
}

using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Office_Project.Data;
using Office_Project.Models;
using Office_Project.Static;
using System.Diagnostics;

namespace Office_Project.Controllers
{

    public class HomeController : Controller
    {
        private readonly AppDBContext db;
        public HomeController(AppDBContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
            var data = db.Products.ToList();
            return View(data);
        }
        [Authorize(Roles = UsersRole.Admin)]
        public IActionResult Create()
        {
            var vm = new CategorySubCategoryVM
            {
                Categories = db.Categories.ToList(),
                SubCategories = new List<SubCategory>()
            };

            return View(vm);
        }
        // POST
        [HttpPost]
        public IActionResult Create(CategorySubCategoryVM vm)
        {
            vm.Categories = db.Categories.ToList();

            vm.SubCategories = db.SubCategories
                .Where(sc => sc.CategoryId == vm.CategoryId)
                .ToList();

            return View(vm);
        }
        
        //public IActionResult Edit(int Id)
        //{
        //    var data = db.Students.Where(model => model.Id == Id).FirstOrDefault();
        //    return View(data);
        //}
        //[HttpPost]
        //public IActionResult Edit(Student obj)
        //{
        //    db.Entry(obj).State = Microsoft.EntityFrameworkCore.EntityState.Modified;
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}
        //public IActionResult Delete(int Id)
        //{
        //    var data = db.Students.Where(model => model.Id == Id).FirstOrDefault();
        //    db.Entry(data).State = Microsoft.EntityFrameworkCore.EntityState.Deleted;
        //    db.SaveChanges();
        //    return RedirectToAction("Index");
        //}
    }
}

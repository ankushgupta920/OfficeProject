﻿using Microsoft.AspNetCore.Identity;
using Office_Project.Models;
using Office_Project.Static;
using System;

namespace Office_Project.Data
{
    public class AppDbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                var context = serviceScope.ServiceProvider.GetService<AppDBContext>();
                context.Database.EnsureCreated();

                // Seed Categories
                if (!context.Categories.Any())
                {
                    context.Categories.AddRange(new List<Category>()
                    {
                    new Category { CategoryName = "Electronics" },
                    new Category { CategoryName = "Clothing" },
                    new Category { CategoryName = "Books" }
                    });
                    context.SaveChanges();
                }

                // Seed SubCategories
                if (!context.SubCategories.Any())
                {
                    context.SubCategories.AddRange(new List<SubCategory>()
                {
                    new SubCategory { SubCategoryName = "Mobile", CategoryId = 1 },
                    new SubCategory { SubCategoryName = "Laptop", CategoryId = 1 },

                    new SubCategory { SubCategoryName = "Men Wear", CategoryId = 2 },
                    new SubCategory { SubCategoryName = "Women Wear", CategoryId = 2 },

                    new SubCategory { SubCategoryName = "Programming", CategoryId = 3 },
                    new SubCategory { SubCategoryName = "Novels", CategoryId = 3 }
                });
                    context.SaveChanges();
                }

                // Seed Products
                if (!context.Products.Any())
                {
                    context.Products.AddRange(new List<Product>()
                {
                    new Product
                    {
                        ProductName = "iPhone 15",
                        Price = 75000,
                        SubCategoryId = 1
                    },
                    new Product
                    {
                        ProductName = "Dell XPS",
                        Price = 95000,
                        SubCategoryId = 2
                    },
                    new Product
                    {
                        ProductName = "T-Shirt",
                        Price = 799,
                        SubCategoryId = 3
                    }
                });
                    context.SaveChanges();
                }
            }
        }

        public static async Task SeedUsersAndRole(IApplicationBuilder applicationBuilder)
        {
            using (var serviceScope = applicationBuilder.ApplicationServices.CreateScope())
            {
                //Roles

                var roleManager = serviceScope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

                if (!await roleManager.RoleExistsAsync(UsersRole.Admin))
                {
                    await roleManager.CreateAsync(new IdentityRole(UsersRole.Admin));
                }
                if (!await roleManager.RoleExistsAsync(UsersRole.User))
                {
                    await roleManager.CreateAsync(new IdentityRole(UsersRole.User));
                }


                //Users
                var UserManager = serviceScope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

                var adminUser = await UserManager.FindByEmailAsync("admin@etickets.com");
                if (adminUser == null)
                {
                    var newAdminUser = new ApplicationUser()
                    {
                        FullName = "Admin User",
                        UserName = "admin-user",
                        Email = "admin@etickets.com",
                        EmailConfirmed = true
                    };
                    await UserManager.CreateAsync(newAdminUser, "Coding@1234");
                    await UserManager.AddToRoleAsync(newAdminUser, UsersRole.Admin);
                }

                var AppUser = await UserManager.FindByEmailAsync("AppUser");
                if (AppUser == null)
                {
                    var newAppUser = new ApplicationUser()
                    {
                        FullName = "Application User",
                        UserName = "app-user",
                        Email = "AppUser",
                        EmailConfirmed = true
                    };
                    await UserManager.CreateAsync(newAppUser, "Coding@1234");
                    await UserManager.AddToRoleAsync(newAppUser, UsersRole.User);
                }

            }
        }
    }
}

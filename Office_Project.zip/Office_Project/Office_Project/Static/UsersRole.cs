﻿namespace Office_Project.Static
{
    public static class UsersRole
    {
        public const string Admin = "Admin";
        public const string User = "User";
    }
}
